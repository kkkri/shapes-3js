/** @public */
export namespace StyleConstants {
    export const defaultComponentBaseZIndex = 'auto';
    export const defaultComponentDragZIndex = '32';
    export const defaultComponentStackMaximisedZIndex = '41';
}
